var group___s_p_i =
[
    [ "SPI Public Functions", "group___s_p_i___public___function.html", "group___s_p_i___public___function" ]
];