var _wait_8c =
[
    [ "SysTick_Handler", "_wait_8c.html#ab5e09814056d617c521549e542639b7e", null ],
    [ "WAIT_GetElapsedMillis", "_wait_8c.html#a704472853537ff855081d868bf2460a4", null ],
    [ "WAIT_init", "_wait_8c.html#a412f96efdc557e4420dc493e2acd7e81", null ],
    [ "WAIT_Milliseconds", "_wait_8c.html#a6b7373d949f2a31278d008cffbf46f00", null ]
];