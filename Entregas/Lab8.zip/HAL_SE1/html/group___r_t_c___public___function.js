var group___r_t_c___public___function =
[
    [ "RTC_GetSeconds", "group___r_t_c___public___function.html#gae5435a51a55c7cd6bde4212a93f1e967", null ],
    [ "RTC_GetValue", "group___r_t_c___public___function.html#ga506e5d1d8d538575e4739d85f4db7ff1", null ],
    [ "RTC_Init", "group___r_t_c___public___function.html#ga8ce39fc6eece59a57c6343c3ee52cbf5", null ],
    [ "RTC_SetSeconds", "group___r_t_c___public___function.html#gacefa177b35b24cdd98a156950f7d051b", null ],
    [ "RTC_SetValue", "group___r_t_c___public___function.html#ga14fa105430d9febf19fe275cee4664d8", null ]
];