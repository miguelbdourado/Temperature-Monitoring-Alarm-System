var group___b_m_p___public___function =
[
    [ "BMP_Init", "group___b_m_p___public___function.html#gaee26be50a2734c0a2be3f1b6be13a794", null ],
    [ "GetReg16", "group___b_m_p___public___function.html#gab915d40fabe3ced5f0b772f2eefd2c46", null ],
    [ "GetReg8", "group___b_m_p___public___function.html#ga5c639cf2e8bafaf402b5ce8da6e4fbc5", null ],
    [ "SetReg8", "group___b_m_p___public___function.html#ga2004f9b4ceeae7e2994dde949f405800", null ]
];