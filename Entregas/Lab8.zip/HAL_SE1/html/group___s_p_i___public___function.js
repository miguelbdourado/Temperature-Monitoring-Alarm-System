var group___s_p_i___public___function =
[
    [ "SPI_ConfigTransfer", "group___s_p_i___public___function.html#gafdfd38280ebbf6be99ed3540c0678313", null ],
    [ "SPI_Init", "group___s_p_i___public___function.html#ga9405ec7074e866a9c74f393f11f18ede", null ],
    [ "SPI_Transfer", "group___s_p_i___public___function.html#ga46290174e86e83d368c8682b50b9c614", null ]
];