var modules =
[
    [ "BMP", "group___b_m_p.html", "group___b_m_p" ],
    [ "FLASH", "group___f_l_a_s_h.html", "group___f_l_a_s_h" ],
    [ "KeyPad", "group___k_e_y_p_a_d.html", "group___k_e_y_p_a_d" ],
    [ "LCDText", "group___l_c_d.html", "group___l_c_d" ],
    [ "LED", "group___l_e_d.html", "group___l_e_d" ],
    [ "RTC", "group___r_t_c.html", "group___r_t_c" ],
    [ "SPI", "group___s_p_i.html", "group___s_p_i" ],
    [ "Wait", "group___w_a_i_t.html", "group___w_a_i_t" ]
];