/*
 * Wait.c
 *
 *  Created on: 28 Oct 2021
 *      Author: Daniel Dron		46101
 *      		Miguel Dourado	46063
 *      		Diogo Cunha		46105
 */

#include "Wait.h"

int WAIT_init()
{
	SystemCoreClockUpdate();
	if (SysTick_Config(SYSTICK_FREQ) == 1) return -1;	//Failed
	return 0;	//Succeeded
}

void SysTick_Handler(void)
{
	__ms++;
}

void WAIT_Milliseconds(uint32_t milliseconds)
{
	uint32_t start = __ms;

	while((__ms - start) < milliseconds)
	{
		__WFI();
	}
}

uint32_t WAIT_GetElapsedMillis(uint32_t start)
{
	return __ms - start;
}
