var modules =
[
    [ "LED", "group___l_e_d.html", "group___l_e_d" ],
    [ "Wait", "group___w_a_i_t.html", "group___w_a_i_t" ]
];