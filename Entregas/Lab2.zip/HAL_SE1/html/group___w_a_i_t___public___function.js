var group___w_a_i_t___public___function =
[
    [ "WAIT_GetElapsedMillis", "group___w_a_i_t___public___function.html#ga704472853537ff855081d868bf2460a4", null ],
    [ "WAIT_init", "group___w_a_i_t___public___function.html#ga412f96efdc557e4420dc493e2acd7e81", null ],
    [ "WAIT_Milliseconds", "group___w_a_i_t___public___function.html#ga6b7373d949f2a31278d008cffbf46f00", null ]
];