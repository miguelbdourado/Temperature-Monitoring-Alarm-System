var group___l_c_d =
[
    [ "LCDText Public Functions", "group___l_c_d___public___function.html", "group___l_c_d___public___function" ],
    [ "LCDText Private Functions", "group___l_c_d___private___function.html", "group___l_c_d___private___function" ]
];