/*
 * SPI.h
 *
 *  Created on: 16 Dec 2021
 *      Author: Daniel Dron
 */

#ifndef SPI_H_
#define SPI_H_

#include "LPC17xx.h"
#include <string.h>

#define ENABLE_SPI (0x1 << 8)

void SPI_Init();


#endif /* SPI_H_ */
