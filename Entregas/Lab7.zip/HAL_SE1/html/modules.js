var modules =
[
    [ "FLASH", "group___f_l_a_s_h.html", "group___f_l_a_s_h" ],
    [ "KeyPad", "group___k_e_y_p_a_d.html", "group___k_e_y_p_a_d" ],
    [ "LCDText", "group___l_c_d.html", "group___l_c_d" ],
    [ "LED", "group___l_e_d.html", "group___l_e_d" ],
    [ "RTC", "group___r_t_c.html", "group___r_t_c" ],
    [ "Wait", "group___w_a_i_t.html", "group___w_a_i_t" ]
];