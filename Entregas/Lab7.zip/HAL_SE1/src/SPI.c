/*
 * SPI.c
 *
 *  Created on: 16 Dec 2021
 *      Author: Daniel Dron
 */


#include "SPI.h"


void setPinModeGPIO(int port, int pin_number, int direction)
{
    LPC_PINCON->PINSEL0 &= ~(0x3 << (22 - 16));
    LPC_GPIO0->FIODIR |= (1 << 22);
}

void SPI_Init()
{

	/*
	 * P0.15 -> MODE 11 (SCK)   OUTPUT
	 * P0.16 -> MODE 11 (SSEL)  OUTPUT
	 * P0.17 -> MODE 11 (MISO)   INPUT
	 * P0.18 -> MODE 11 (MOSI)  OUTPUT
	 */
	LPC_PINCON->PINSEL0 |= (0x3 << 30);
	LPC_PINCON->PINSEL1 |= 0x3F;

	LPC_GPIO0->FIODIR |= (1 << 15);	//OUTPUT
	LPC_GPIO0->FIODIR |= (1 << 16);	//OUTPUT
	LPC_GPIO0->FIODIR &= (0 << 17); // INPUT
	LPC_GPIO0->FIODIR |= (1 << 18); //OUTPUT

	LPC_GPIO0->FIOSET |= (1 << 16); //Disable SSEL


	LPC_SC->PCONP |= ENABLE_SPI;	//Maybe no need? bung



}
